# DragonCores Gothic Resource Pack

This folder is the Java resource-pack source. Zip the *contents* of this folder (pack.mcmeta must be at the root) before hosting it. It includes custom item models/textures, Core equipment icon families, boss-trophy tokens, Bedrock/Geyser mapping manifests, and Bedrock entity geometry source.

The Java pack supplies item appearances only; it does not replace the vanilla living-entity renderer. The Bedrock geometry files are source assets for a Geyser-compatible Bedrock pack and must be packaged/distributed as a separate Bedrock pack by the server owner. Test custom entity definitions against the exact Geyser version in production.
